"""
Read file into texts and calls.
It's ok if you don't understand how to read files.
"""
import csv

with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)

"""
TASK 4:
The telephone company want to identify numbers that might be doing
telephone marketing. Create a set of possible telemarketers:
these are numbers that make outgoing calls but never send texts,
receive texts or receive incoming calls.

Print a message:
"These numbers could be telemarketers: "
<list of numbers>
The list of numbers should be print out one per line in lexicographic order with no duplicates.
"""
#check to see if 1st col calls exists in 2nd col calls, or either col texts

#put 2nd col calls in set
#add 1st & 2nd col calls to set
#put 1st col calls in separate set to remove duplicates
#iterate 1st col calls using membership operators

unique_callers = set()
unique_others = set()
telemarketers = []
for c in calls:
    unique_callers.add(c[0])
    unique_others.add(c[1])
for t in texts:
    unique_others.update([t[0], t[1]])
for u_c in unique_callers:
    if u_c not in unique_others:
        telemarketers.append('\n'+u_c)
telemarketers = ' '.join(sorted(telemarketers))

print("These numbers could be telemarketers: {}".format(telemarketers))

